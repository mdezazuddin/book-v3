<?php $page= "about";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body class="bg-light">
    <main>
        <section class="pt-1 mt-5 section3">
            <div class="container">  
                <div class="row no-gutters">
                    <div class="col-lg-1"></div>
                    <div class="col-lg-10">
                        <div class="row no-gutters shd1 bg-white rounded-lg">
                            <div class="col-lg-6 pt-5 bg-blue1">
                                <div class="mt-5 pt-5 d-lg-block d-none">
                                    <a href="index.php"><img class="mx-auto d-block mt-5 pt-5" src="assets/image/logo.png"></a>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card-body pl-4 pr-4 pt-1 pb-4 pt-4">
                                    <h5 class="font-weight-bold">REGISTRATION</h5>
                                    <p class="text-muted h6">Welcome back, please login to your account.</p>
                                    <form class="mt-4" name="frmLogin" id="frmLogin" action="" method="GET" target="#">
                                        <div class="form-row">
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your Name</label>
                                                <input type="text" name="txtFullName" id="txtFullName"
                                                    class="form-control shadow-none"
                                                    placeholder="Full Name">
                                                <span id="Nameerror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your Email</label>
                                                <input type="email" name="txtEmail" id="txtEmail"
                                                    class="form-control shadow-none"
                                                    placeholder="Email">
                                                <span id="Emailerror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your Phone</label>
                                                <input type="tel" name="txtPhone" id="txtPhone"
                                                    class="form-control shadow-none"
                                                    placeholder="Phone">
                                                <span id="Phoneerror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your Password</label>
                                                <input type="Password" name="txtPassword" id="txtPassword"
                                                    class="form-control shadow-none"
                                                    placeholder="Password">
                                                <span id="Passworderror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your Country</label>
                                                <select class="form-control shadow-none" name="SelCountry" id="SelCountry">
                                                    <option selected>Selected</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                </select>
                                                <span id="Countryerror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12 col-lg-6">
                                                <label for="name-field" class="text-black-50 small">Your State</label>
                                                <select class="form-control shadow-none" name="SelState" id="SelState">
                                                    <option selected>Selected</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                    <option>India</option>
                                                </select>
                                                <span id="Stateerror" style="color:red"></span>
                                            </div>
                                            <div class="form-group col-12">
                                                <label for="name-field" class="text-black-50 small">Your Address</label>
                                                <textarea type="text" name="txtStreetAddress" id="txtStreetAddress"
                                                    class="form-control shadow-none"
                                                    placeholder="Street Address"></textarea>
                                                <span id="StreetAddresserror" style="color:red"></span>
                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-between mt-2">
                                            <div class="d-flex justify-content-between mt-2">
                                                <input type="submit" value="Sign up" class="btns9 bg-gold btn btn  text-white pl-4 rounded-pill pt-1 pr-4">  
                                            </div>

                                            <p class="mt-3 mb-0">
                                                <span class="mr-2 small">Do you already have an account?</span><a class="card-link text-gold pt-1" href="login.php">Sign In</a>  
                                            </p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div> 
        </section>
    </div>
</main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>